package org.ies.examen.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.ies.examen.domain.model.Vehicle

class AddVehicleViewModel: ViewModel() {

    private val _vehicle = MutableStateFlow<Vehicle>(
        Vehicle("", "", 0, "", "")
    )


    val vehicle: StateFlow<Vehicle> = _vehicle

    fun setId(id: String) {
        _vehicle.value = _vehicle.value.copy(id = id)
    }

    fun setBrand(brand: String) {
        _vehicle.value = _vehicle.value.copy(brand = brand)
    }

    fun setKm(km: Int) {
        _vehicle.value = _vehicle.value.copy(km = km)
    }

    fun setPlate(plate: String) {
        _vehicle.value = _vehicle.value.copy(plate = plate)
    }

    fun setdescription(description: String) {
        _vehicle.value = _vehicle.value.copy(description = description)
    }



}