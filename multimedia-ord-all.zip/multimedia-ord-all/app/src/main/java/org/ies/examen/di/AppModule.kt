package org.ies.examen.di

import org.koin.dsl.module


val appModule = module {

}