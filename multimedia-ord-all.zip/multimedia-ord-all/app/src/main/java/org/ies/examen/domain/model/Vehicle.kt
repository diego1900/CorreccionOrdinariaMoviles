package org.ies.examen.domain.model

data class Vehicle(
    val id: String,
    val brand: String,
    val km: Int,
    val plate: String,
    val description: String

)