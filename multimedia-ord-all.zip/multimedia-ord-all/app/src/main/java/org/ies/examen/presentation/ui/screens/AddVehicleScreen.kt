package org.ies.examen.presentation.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


@Composable
fun AddVehicleScreen() {

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) { paddingValues ->
        /* TODO Implementa la ventana añadir un vehículo */
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ){
            TextField(
                value = "",
                onValueChange = {},
                placeholder = { Text(text = "Marca") },
                modifier = Modifier
                    .fillMaxWidth()
            )
            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp)
            )
            TextField(
                value = "",
                onValueChange = {},
                placeholder = { Text(text = "Kms") },
                modifier = Modifier
                    .fillMaxWidth()
            )
            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp)
            )
            TextField(
                value = "",
                onValueChange = {},
                placeholder = { Text(text = "Matrícula (plate)") },
                modifier = Modifier
                    .fillMaxWidth()
            )
            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp)
            )
            TextField(
                value = "",
                onValueChange = {},
                placeholder = { Text(text = "Descripción") },
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1F)
            )
            Spacer(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
            ){
                Button(
                    onClick = { /*TODO*/ },
                    modifier = Modifier.align(Alignment.CenterVertically)

                ) {
                    Text(text = "Guardar")
                }
                Spacer(
                    modifier = Modifier
                        .padding(4.dp)
                )
                Button(
                    onClick = { /*TODO*/ },
                    modifier = Modifier.align(Alignment.CenterVertically)

                ) {
                    Text(text = "Cancelar")
                }
            }
        }
    }
}

@Preview
@Composable
fun AddVehicleScreenPreview() {
    AddVehicleScreen()
}

